<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "volunteer";
$conn = new mysqli($servername, $username, $password, $dbname);
// Create connection

?>